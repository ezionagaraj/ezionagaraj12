var sidebar=document.querySelector(".sidenavbar")
function show(){
    sidebar.style.left="0"
}

function closebar(){
        sidebar.style.left="-60%"
}